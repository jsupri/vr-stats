<div id="navBarLeft">
	<ul>
		<li><a id="nav-index" href="./index.php">Home</a></li>
		<li><a id="nav-selector" href="./selector.php">Table Selector</a></li>
		<!-- 
		<li><a id="nav-vmfulllist" href="./vmfulllist.php">VM Full List</a></li>
		<li><a id="nav-vrconfigured" href="./vrconfigured.php">VR Configured</a></li>
		<li><a id="nav-srmplaceholders" href="./srmplaceholders.php">SRM Placeholders </a></li>
		<li><a id="nav-vrerrorpaused" href="./vrerrorpaused.php">VR Error Paused</a></li>
		<li><a id="nav-vrnotconfiguredpoweredoff" href="./vrnotconfiguredpoweredoff.php">VR Not Configured Powered Off</a></li>
		<li><a id="nav-vrnotconfiguredpoweredon" href="./vrnotconfiguredpoweredon.php">VR Not Configured Powered On</a></li>
		<li><a id="nav-vrreplicationhistory" href="./vrreplicationhistory.php">VR Replication History</a></li>
		-->
	</ul>
</div>