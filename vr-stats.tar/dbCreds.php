<?php
$dbuser = "webuser";
$dbpass = "Pass20Word";
$dbname = "stats";
?>